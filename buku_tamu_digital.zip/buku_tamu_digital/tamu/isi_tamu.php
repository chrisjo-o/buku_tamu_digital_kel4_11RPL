<?php

include "../includes/koneksi.php";

error_reporting(E_ALL);
ini_set('display_errors', 1);

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nama_tamu = trim($_POST['nama_tamu']);
    $instansi = trim($_POST['instansi']);
    $tujuan = trim($_POST['tujuan']);
    $waktu_kunjungan = date("Y-m-d H:i:s", strtotime($_POST['waktu_kunjungan']));
    $keterangan = trim($_POST['keterangan']);

    $stmt = mysqli_prepare(
        $koneksi,
        "INSERT INTO tamu
        (
            nama_tamu,
            instansi,
            tujuan,
            waktu_kunjungan,
            keterangan
        )
        VALUES
        (?, ?, ?, ?, ?)"
    );

    if (!$stmt) {
        die("Prepare gagal : " . mysqli_error($koneksi));
    }

    mysqli_stmt_bind_param(
        $stmt,
        "sssss",
        $nama_tamu,
        $instansi,
        $tujuan,
        $waktu_kunjungan,
        $keterangan
    );

    if (mysqli_stmt_execute($stmt)) {

        mysqli_stmt_close($stmt);

        header("Location: berhasil.php");
        exit;

    } else {

        die("Execute gagal : " . mysqli_stmt_error($stmt));

    }

}
?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Isi Buku Tamu | Buku Tamu Digital</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.css" rel="stylesheet">

    <link rel="stylesheet" href="../assets/css/style.css">

</head>

<body class="guest-page">

<div class="overlay"></div>

<div class="container py-5">

    <div class="row justify-content-center">

        <div class="col-lg-7">

            <div class="card shadow-lg">

                <div class="card-body p-5">

                    <div class="text-center mb-4">

                        <i class="bi bi-journal-bookmark-fill display-4 text-primary"></i>

                        <h2 class="fw-bold mt-3">
                            Buku Tamu Digital
                        </h2>

                        <p class="text-muted">
                            Silakan lengkapi data kunjungan Anda.
                        </p>

                    </div>

                    <?php if (!empty($error)) : ?>

                        <div class="alert alert-danger">

                            <?= $error; ?>

                        </div>

                    <?php endif; ?>

                    <form action="" method="POST">

                        <div class="mb-3">

                            <label class="form-label">

                                Nama Lengkap

                            </label>

                            <input
                                type="text"
                                name="nama_tamu"
                                class="form-control"
                                value="<?= isset($_POST['nama_tamu']) ? htmlspecialchars($_POST['nama_tamu']) : ''; ?>"
                                required>

                        </div>

                        <div class="mb-3">

                            <label class="form-label">

                                Instansi / Asal

                            </label>

                            <input
                                type="text"
                                name="instansi"
                                class="form-control"
                                value="<?= isset($_POST['instansi']) ? htmlspecialchars($_POST['instansi']) : ''; ?>"
                                required>

                        </div>

                        <div class="mb-3">

                            <label class="form-label">

                                Tujuan Kunjungan

                            </label>

                            <input
                                type="text"
                                name="tujuan"
                                class="form-control"
                                value="<?= isset($_POST['tujuan']) ? htmlspecialchars($_POST['tujuan']) : ''; ?>"
                                required>

                        </div>

                        <div class="mb-3">

                            <label class="form-label">

                                Waktu Kunjungan

                            </label>

                            <input
                                type="datetime-local"
                                name="waktu_kunjungan"
                                class="form-control"
                                value="<?= isset($_POST['waktu_kunjungan']) ? htmlspecialchars($_POST['waktu_kunjungan']) : ''; ?>"
                                required>

                        </div>

                        <div class="mb-4">

                            <label class="form-label">

                                Keterangan

                            </label>

                            <textarea
                                name="keterangan"
                                rows="4"
                                class="form-control"
                                placeholder="Opsional"><?= isset($_POST['keterangan']) ? htmlspecialchars($_POST['keterangan']) : ''; ?></textarea>

                        </div>

                        <div class="d-grid gap-2">

                            <button
                                type="submit"
                                name="simpan"
                                class="btn btn-primary">

                                <i class="bi bi-send-fill"></i>

                                Kirim Data

                            </button>

                            <a
                                href="../index.php"
                                class="btn btn-outline-secondary">

                                <i class="bi bi-arrow-left"></i>

                                Kembali ke Beranda

                            </a>

                        </div>

                    </form>

                </div>

            </div>

        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>

</body>

</html>