<!DOCTYPE html>
<html lang="id">
<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Berhasil | Buku Tamu Digital</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.css" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../assets/css/style.css">

</head>

<body class="guest-page">

<div class="overlay"></div>

<div class="container">

    <div class="row justify-content-center align-items-center min-vh-100">

        <div class="col-lg-6">

            <div class="card shadow-lg border-0 p-5 text-center">

                <div class="mb-4">

                    <i class="bi bi-check-circle-fill text-success display-1"></i>

                </div>

                <h2 class="fw-bold mb-3">

                    Terima Kasih

                </h2>

                <p class="text-muted mb-4">

                    Data kunjungan Anda telah berhasil disimpan ke dalam Buku Tamu Digital.

                </p>

                <div class="d-grid gap-2">

                    <a href="daftar_tamu.php" class="btn btn-primary">

                        <i class="bi bi-card-list"></i>
                        Lihat Daftar Tamu

                    </a>

                    <a href="../index.php" class="btn btn-outline-secondary">

                        <i class="bi bi-house-door"></i>
                        Kembali ke Beranda

                    </a>

                </div>

            </div>

        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>

</body>
</html>