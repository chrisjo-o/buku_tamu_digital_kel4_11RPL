<?php
include "../includes/koneksi.php";

$query = mysqli_query($koneksi, "SELECT * FROM tamu ORDER BY waktu_kunjungan DESC");
?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Daftar Tamu | Buku Tamu Digital</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.css" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="../assets/css/style.css">

</head>

<body class="guest-page">

<div class="overlay"></div>

<div class="container py-5">

    <div class="card shadow-lg border-0">

        <div class="card-header bg-primary text-white">

            <div class="d-flex justify-content-between align-items-center">

                <h4 class="mb-0">

                    <i class="bi bi-people-fill"></i>

                    Daftar Tamu

                </h4>

                <a href="../index.php" class="btn btn-light btn-sm">

                    <i class="bi bi-house-door-fill"></i>

                    Beranda

                </a>

            </div>

        </div>

        <div class="card-body">

            <div class="row mb-3">

                <div class="col-md-5">

                    <input
                        type="text"
                        class="form-control"
                        id="cariTamu"
                        placeholder="Cari nama, instansi atau tujuan...">

                </div>

            </div>

            <div class="table-responsive">

                <table class="table table-hover align-middle" id="tabelTamu">

                    <thead class="table-primary">

                        <tr>

                            <th>No</th>

                            <th>Nama</th>

                            <th>Instansi</th>

                            <th>Tujuan</th>

                            <th>Waktu Kunjungan</th>

                            <th>Keterangan</th>

                        </tr>

                    </thead>

                    <tbody>

                        <?php

                        $no = 1;

                        if (mysqli_num_rows($query) > 0) :

                            while ($data = mysqli_fetch_assoc($query)) :

                        ?>

                        <tr>

                            <td><?= $no++; ?></td>

                            <td><?= htmlspecialchars($data['nama_tamu']); ?></td>

                            <td><?= htmlspecialchars($data['instansi']); ?></td>

                            <td><?= htmlspecialchars($data['tujuan']); ?></td>

                            <td>

                                <span class="badge bg-primary">

                                    <?= date('d M Y', strtotime($data['waktu_kunjungan'])); ?>

                                </span>

                                <br>

                                <small class="text-muted">

                                    <?= date('H:i', strtotime($data['waktu_kunjungan'])); ?>

                                </small>

                            </td>

                            <td>

                                <?php

                                if (!empty($data['keterangan'])) {

                                    echo htmlspecialchars($data['keterangan']);

                                } else {

                                    echo "<span class='text-secondary'>-</span>";

                                }

                                ?>

                            </td>

                        </tr>

                        <?php 
                            endwhile; 
                        else :
                        ?>

                        <tr>
                            <td colspan="6" class="text-center py-4 text-muted">Belum ada data tamu.</td>
                        </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

            <div class="text-center mt-4">

                <a href="isi_tamu.php" class="btn btn-primary">

                    <i class="bi bi-person-plus-fill"></i>

                    Isi Buku Tamu Lagi

                </a>

            </div>

        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>

<script>
// Live Search untuk tabel daftar tamu publik
document.addEventListener('DOMContentLoaded', function () {
    const inputCari = document.getElementById('cariTamu');
    const tabelTamu = document.getElementById('tabelTamu');

    if (inputCari && tabelTamu) {
        inputCari.addEventListener('keyup', function () {
            const filter = this.value.toLowerCase();
            const rows = tabelTamu.querySelectorAll('tbody tr');

            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                if (text.includes(filter)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }
});
</script>

</body>

</html>