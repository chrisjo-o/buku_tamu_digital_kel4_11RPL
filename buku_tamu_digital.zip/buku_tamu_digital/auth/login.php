<?php
session_start();

if (isset($_SESSION['id_user'])) {
    header("Location: ../dashboard/dashboard.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Login | Buku Tamu Digital</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">

</head>

<body class="landing-page">

<div class="overlay">

    <div class="container">

        <div class="row justify-content-center align-items-center hero-section">

            <div class="col-lg-5">

                <div class="card shadow border-0 hero-card">

                    <div class="card-body p-5">

                        <div class="text-center mb-4">

                            <i class="bi bi-person-circle display-3 text-primary"></i>

                            <h2 class="fw-bold mt-3">
                                Login Administrator
                            </h2>

                            <p class="text-secondary">

                                Masukkan username dan password untuk masuk ke dashboard.

                            </p>

                        </div>

                        <?php if (isset($_GET['pesan'])) : ?>

                            <div class="alert alert-danger">

                                Username atau Password salah.

                            </div>

                        <?php endif; ?>

                        <form action="proses_login.php" method="POST">

                            <div class="mb-3">

                                <label class="form-label">

                                    Username

                                </label>

                                <input
                                    type="text"
                                    name="username"
                                    class="form-control"
                                    placeholder="Masukkan username"
                                    required>

                            </div>

                            <div class="mb-4">

                                <label class="form-label">

                                    Password

                                </label>

                                <input
                                    type="password"
                                    name="password"
                                    class="form-control"
                                    placeholder="Masukkan password"
                                    required>

                            </div>

                            <div class="d-grid gap-2">

                                <button type="submit" class="btn btn-primary">

                                    <i class="bi bi-box-arrow-in-right"></i>

                                    Login

                                </button>

                                <a href="../index.php" class="btn btn-outline-secondary">

                                    <i class="bi bi-arrow-left"></i>

                                    Kembali ke Beranda

                                </a>

                            </div>

                        </form>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="../assets/js/script.js"></script>

</body>

</html>