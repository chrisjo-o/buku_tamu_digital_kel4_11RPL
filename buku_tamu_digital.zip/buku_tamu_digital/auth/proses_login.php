<?php

session_start();

include "../includes/koneksi.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = mysqli_real_escape_string($koneksi, $_POST['password']);

    $query = "SELECT * FROM user
              WHERE username = '$username'
              AND password = '$password'";

    $result = mysqli_query($koneksi, $query);

    if (mysqli_num_rows($result) == 1) {

        $user = mysqli_fetch_assoc($result);

        $_SESSION['id_user'] = $user['id_user'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['nama_lengkap'] = $user['nama_lengkap'];

        header("Location: ../dashboard/dashboard.php");
        exit;

    } else {

        header("Location: login.php?pesan=gagal");
        exit;

    }

} else {

    header("Location: login.php");
    exit;

}

?>