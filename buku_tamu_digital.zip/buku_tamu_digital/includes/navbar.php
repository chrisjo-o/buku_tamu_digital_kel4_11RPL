<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">

        <a class="navbar-brand fw-bold" href="#">
            <i class="bi bi-book-half text-primary"></i>
            Buku Tamu Digital
        </a>

        <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarMenu">

            <span class="navbar-toggler-icon"></span>

        </button>

        <div class="collapse navbar-collapse" id="navbarMenu">

            <ul class="navbar-nav ms-auto align-items-center">

                <li class="nav-item me-3">

                    <span class="fw-semibold text-dark">
                        <i class="bi bi-person-circle"></i>
                        <?= $_SESSION['nama_lengkap']; ?>
                    </span>

                </li>

                <li class="nav-item">

                    <a href="../auth/logout.php" class="btn btn-primary">

                        <i class="bi bi-box-arrow-right"></i>
                        Logout

                    </a>

                </li>

            </ul>

        </div>

    </div>
</nav>