<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Buku Tamu Digital</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/style.css">

</head>

<body class="landing-page">

    <div class="overlay">

        <!-- Navbar -->

        <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">

            <div class="container">

                <a class="navbar-brand fw-bold" href="index.php">

                    <i class="bi bi-book-half text-primary"></i>
                    Buku Tamu Digital

                </a>

            </div>

        </nav>

        <!-- Hero -->

        <div class="container">

            <div class="row justify-content-center align-items-center hero-section">

                <div class="col-lg-7">

                    <div class="card shadow border-0 hero-card">

                        <div class="card-body text-center p-5">

                            <i class="bi bi-building display-3 text-primary"></i>

                            <h1 class="fw-bold mt-4">

                                Selamat Datang

                            </h1>

                            <p class="text-secondary mt-3">

                                Selamat datang di Website Buku Tamu Digital.
                                Silakan login sebagai administrator untuk mengelola data tamu,
                                atau masuk sebagai tamu untuk mengisi buku tamu.

                            </p>

                            <div class="d-grid gap-3 mt-4">

                                <a href="auth/login.php" class="btn btn-primary btn-lg">

                                    <i class="bi bi-box-arrow-in-right"></i>

                                    Login Admin

                                </a>

                                <a href="tamu/isi_tamu.php" class="btn btn-outline-primary btn-lg">

                                    <i class="bi bi-person-plus"></i>

                                    Masuk Sebagai Tamu

                                </a>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <script src="assets/js/script.js"></script>

</body>

</html>