// ======================================================
// Buku Tamu Digital
// assets/js/script.js
// ======================================================

document.addEventListener("DOMContentLoaded", () => {

    // ==================================================
    // Fade In
    // ==================================================

    const hero = document.querySelector(".hero-content");
    const card = document.querySelector(".form-card");

    if (hero) {
        hero.style.opacity = "1";
    }

    if (card) {
        card.style.opacity = "1";
    }

    // ==================================================
    // Focus Effect
    // ==================================================

    const inputs = document.querySelectorAll(".form-control");

    inputs.forEach(input => {

        input.addEventListener("focus", function () {

            this.parentElement.classList.add("active");

        });

        input.addEventListener("blur", function () {

            this.parentElement.classList.remove("active");

        });

    });

    // ==================================================
    // Reset Confirmation
    // ==================================================

    const resetButton = document.querySelector("button[type='reset']");

    if (resetButton) {

        resetButton.addEventListener("click", function (e) {

            const konfirmasi = confirm("Yakin ingin mengosongkan seluruh data?");

            if (!konfirmasi) {

                e.preventDefault();

            }

        });

    }

    // ==================================================
    // Loading Submit
    // ==================================================

    const form = document.querySelector("form");

    if (form) {

        form.addEventListener("submit", function () {

            const submitButton = this.querySelector("button[type='submit']");

            if (submitButton) {

                submitButton.disabled = true;

                submitButton.innerHTML =
                    '<span class="spinner-border spinner-border-sm me-2"></span>Menyimpan...';

            }

        });

    }

});

// ==================================================
// Live Search
// ==================================================

const cariTamu = document.getElementById("cariTamu");

if (cariTamu) {

    cariTamu.addEventListener("keyup", function () {

        const keyword = this.value.toLowerCase();

        const rows = document.querySelectorAll("#tabelTamu tbody tr");

        rows.forEach(function (row) {

            const text = row.textContent.toLowerCase();

            if (text.includes(keyword)) {
                row.style.display = "";
            } else {
                row.style.display = "none";
            }

        });

    });

}