<?php

include "../includes/session.php";
include "../includes/koneksi.php";

if (!isset($_GET['id'])) {
    header("Location: data_tamu.php");
    exit;
}

$id = (int) $_GET['id'];

$cek = mysqli_query($koneksi, "SELECT * FROM tamu WHERE id_tamu = $id");

if (mysqli_num_rows($cek) == 0) {
    header("Location: data_tamu.php");
    exit;
}

$hapus = mysqli_query($koneksi, "DELETE FROM tamu WHERE id_tamu = $id");

if ($hapus) {

    header("Location: data_tamu.php?pesan=hapus");
    exit;

} else {

    header("Location: data_tamu.php?pesan=gagal");
    exit;

}

?>