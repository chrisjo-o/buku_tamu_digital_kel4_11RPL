<?php

include "../includes/session.php";
include "../includes/koneksi.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nama_tamu = mysqli_real_escape_string($koneksi, $_POST['nama_tamu']);
    $instansi = mysqli_real_escape_string($koneksi, $_POST['instansi']);
    $tujuan = mysqli_real_escape_string($koneksi, $_POST['tujuan']);
    $waktu_kunjungan = $_POST['waktu_kunjungan'];
    $keterangan = mysqli_real_escape_string($koneksi, $_POST['keterangan']);

    $query = "INSERT INTO tamu
            (nama_tamu, instansi, tujuan, waktu_kunjungan, keterangan)
            VALUES
            ('$nama_tamu', '$instansi', '$tujuan', '$waktu_kunjungan', '$keterangan')";

    if (mysqli_query($koneksi, $query)) {

        header("Location: data_tamu.php?pesan=tambah");
        exit;

    } else {

        $error = "Data gagal disimpan. " . mysqli_error($koneksi);

    }

}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Tambah Tamu | Buku Tamu Digital</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.css" rel="stylesheet">

    <link rel="stylesheet" href="../assets/css/style.css">

</head>

<body>

<?php include "../includes/navbar.php"; ?>

<div class="overlay"></div>

<div class="container py-5">

    <div class="row justify-content-center">

        <div class="col-lg-8">

            <div class="card shadow-sm border-0">

                <div class="card-body p-4">

                    <h2 class="fw-bold mb-4">

                        <i class="bi bi-person-plus-fill text-primary"></i>

                        Tambah Data Tamu

                    </h2>

                    <?php if (isset($error)) : ?>

                        <div class="alert alert-danger">

                            <?= $error; ?>

                        </div>

                    <?php endif; ?>

                    <form method="POST">

                        <div class="mb-3">

                            <label class="form-label">
                                Nama Tamu
                            </label>

                            <input
                                type="text"
                                name="nama_tamu"
                                class="form-control"
                                required>

                        </div>

                        <div class="mb-3">

                            <label class="form-label">
                                Instansi
                            </label>

                            <input
                                type="text"
                                name="instansi"
                                class="form-control"
                                required>

                        </div>

                        <div class="mb-3">

                            <label class="form-label">
                                Tujuan
                            </label>

                            <input
                                type="text"
                                name="tujuan"
                                class="form-control"
                                required>

                        </div>

                        <div class="mb-3">

                            <label class="form-label">
                                Waktu Kunjungan
                            </label>

                            <input
                                type="datetime-local"
                                name="waktu_kunjungan"
                                class="form-control"
                                required>

                        </div>

                        <div class="mb-4">

                            <label class="form-label">
                                Keterangan
                            </label>

                            <textarea
                                name="keterangan"
                                rows="4"
                                class="form-control"></textarea>

                        </div>

                        <div class="d-flex justify-content-between">

                            <a href="data_tamu.php" class="btn btn-secondary">

                                <i class="bi bi-arrow-left"></i>

                                Kembali

                            </a>

                            <button
                                type="submit"
                                name="simpan"
                                class="btn btn-primary">

                                <i class="bi bi-floppy"></i>

                                Simpan

                            </button>

                        </div>

                    </form>

                </div>

            </div>

        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="../assets/js/script.js"></script>

</body>

</html>