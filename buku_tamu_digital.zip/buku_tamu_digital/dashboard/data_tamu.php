<?php

include "../includes/session.php";
include "../includes/koneksi.php";

$query = mysqli_query($koneksi, "SELECT * FROM tamu ORDER BY waktu_kunjungan DESC");
$totalTamu = mysqli_num_rows($query);

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Data Tamu | Buku Tamu Digital</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">

</head>

<body>

<?php include "../includes/navbar.php"; ?>

<div class="overlay"></div>

<div class="container py-5">

    <?php if (isset($_GET['pesan'])) : ?>

        <?php if ($_GET['pesan'] == "tambah") : ?>

            <div class="alert alert-success alert-dismissible fade show">
                <i class="bi bi-check-circle-fill"></i>
                Data tamu berhasil ditambahkan.
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>

        <?php elseif ($_GET['pesan'] == "edit") : ?>

            <div class="alert alert-primary alert-dismissible fade show">
                <i class="bi bi-pencil-square"></i>
                Data tamu berhasil diperbarui.
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>

        <?php elseif ($_GET['pesan'] == "hapus") : ?>

            <div class="alert alert-danger alert-dismissible fade show">
                <i class="bi bi-trash-fill"></i>
                Data tamu berhasil dihapus.
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>

        <?php elseif ($_GET['pesan'] == "gagal") : ?>

            <div class="alert alert-warning alert-dismissible fade show">
                <i class="bi bi-exclamation-triangle-fill"></i>
                Terjadi kesalahan, silakan coba kembali.
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>

        <?php endif; ?>

    <?php endif; ?>

    <div class="card shadow-lg border-0">

        <div class="card-header bg-primary text-white">

            <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">

                <div>

                    <h4 class="mb-1">
                        <i class="bi bi-people-fill"></i>
                        Data Tamu
                    </h4>

                    <small>
                        Kelola seluruh data tamu yang berkunjung.
                    </small>

                </div>

                <a href="tambah.php" class="btn btn-light">

                    <i class="bi bi-plus-circle"></i>
                    Tambah Tamu

                </a>

            </div>

        </div>

        <div class="card-body">

            <div class="row mb-4">

                <div class="col-md-5">

                    <input
                        type="text"
                        class="form-control"
                        id="cariTamu"
                        placeholder="Cari nama, instansi, tujuan atau keterangan...">

                </div>

                <div class="col-md-7 text-md-end mt-3 mt-md-0">

                    <span class="badge bg-primary fs-6 p-2">

                        <i class="bi bi-person-lines-fill"></i>
                        Total Data : <?= $totalTamu; ?> Tamu

                    </span>

                </div>

            </div>

            <div class="table-responsive">

                <table class="table table-hover align-middle" id="tabelTamu">

                    <thead class="table-primary">

                        <tr>

                            <th width="60">No</th>
                            <th>Nama</th>
                            <th>Instansi</th>
                            <th>Tujuan</th>
                            <th>Waktu Kunjungan</th>
                            <th>Keterangan</th>
                            <th class="text-center" width="140">Aksi</th>

                        </tr>

                    </thead>

                    <tbody>

<?php
$no = 1;

if (mysqli_num_rows($query) > 0) :

while ($tamu = mysqli_fetch_assoc($query)) :
?>
                        <tr>

                            <td><?= $no++; ?></td>

                            <td>

                                <div class="fw-semibold">
                                    <?= htmlspecialchars($tamu['nama_tamu']); ?>
                                </div>

                            </td>

                            <td>
                                <?= htmlspecialchars($tamu['instansi']); ?>
                            </td>

                            <td>
                                <?= htmlspecialchars($tamu['tujuan']); ?>
                            </td>

                            <td>

                                <span class="badge bg-primary">
                                    <?= date('d M Y', strtotime($tamu['waktu_kunjungan'])); ?>
                                </span>

                                <br>

                                <small class="text-muted">
                                    <?= date('H:i', strtotime($tamu['waktu_kunjungan'])); ?>
                                </small>

                            </td>

                            <td>

                                <?php if (!empty($tamu['keterangan'])) : ?>

                                    <?= htmlspecialchars($tamu['keterangan']); ?>

                                <?php else : ?>

                                    <span class="text-secondary">-</span>

                                <?php endif; ?>

                            </td>

                            <td class="text-center">

                                <a
                                    href="edit.php?id=<?= $tamu['id_tamu']; ?>"
                                    class="btn btn-warning btn-sm me-1"
                                    title="Edit">

                                    <i class="bi bi-pencil-square"></i>

                                </a>

                                <a
                                    href="hapus.php?id=<?= $tamu['id_tamu']; ?>"
                                    class="btn btn-danger btn-sm"
                                    title="Hapus"
                                    onclick="return confirm('Yakin ingin menghapus data ini?')">

                                    <i class="bi bi-trash"></i>

                                </a>

                            </td>

                        </tr>

<?php

endwhile;

else :

?>

                        <tr>

                            <td colspan="7" class="text-center py-5">

                                <i class="bi bi-inbox display-5 text-secondary"></i>

                                <h5 class="mt-3 text-secondary">

                                    Belum Ada Data Tamu

                                </h5>

                                <p class="text-muted mb-4">

                                    Silakan tambahkan data tamu terlebih dahulu.

                                </p>

                                <a href="tambah.php" class="btn btn-primary">

                                    <i class="bi bi-plus-circle"></i>

                                    Tambah Tamu

                                </a>

                            </td>

                        </tr>

<?php

endif;

?>

                    </tbody>

                </table>

            </div>
            
        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>

<script>
// Live Search untuk memfilter baris tabel secara instan
document.addEventListener('DOMContentLoaded', function () {
    const inputCari = document.getElementById('cariTamu');
    const tabelTamu = document.getElementById('tabelTamu');

    if (inputCari && tabelTamu) {
        inputCari.addEventListener('keyup', function () {
            const filter = this.value.toLowerCase();
            const rows = tabelTamu.querySelectorAll('tbody tr');

            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                if (text.includes(filter)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }
});
</script>

</body>
</html>