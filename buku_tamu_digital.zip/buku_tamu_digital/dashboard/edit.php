<?php

include "../includes/session.php";
include "../includes/koneksi.php";

if (!isset($_GET['id'])) {
    header("Location: data_tamu.php");
    exit;
}

$id = (int) $_GET['id'];

$query = mysqli_query($koneksi, "SELECT * FROM tamu WHERE id_tamu = $id");

if (mysqli_num_rows($query) == 0) {
    header("Location: data_tamu.php");
    exit;
}

$tamu = mysqli_fetch_assoc($query);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $nama_tamu = mysqli_real_escape_string($koneksi, $_POST['nama_tamu']);
    $instansi = mysqli_real_escape_string($koneksi, $_POST['instansi']);
    $tujuan = mysqli_real_escape_string($koneksi, $_POST['tujuan']);
    $waktu_kunjungan = date("Y-m-d H:i:s", strtotime($_POST['waktu_kunjungan']));
    $keterangan = mysqli_real_escape_string($koneksi, $_POST['keterangan']);

    $update = mysqli_query($koneksi, "
        UPDATE tamu SET
        nama_tamu = '$nama_tamu',
        instansi = '$instansi',
        tujuan = '$tujuan',
        waktu_kunjungan = '$waktu_kunjungan',
        keterangan = '$keterangan'
        WHERE id_tamu = '$id'
    ");

    if ($update) {
        header("Location: data_tamu.php?pesan=edit");
        exit;
    } else {
        $error = "Data gagal diperbarui. " . mysqli_error($koneksi);
    }
}

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Edit Data Tamu | Buku Tamu Digital</title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.css" rel="stylesheet">

    <link rel="stylesheet" href="../assets/css/style.css">

</head>

<body>

<?php include "../includes/navbar.php"; ?>

<div class="overlay"></div>

<div class="container py-5">

    <div class="row justify-content-center">

        <div class="col-lg-8">

            <div class="card shadow-sm border-0">

                <div class="card-body p-4">

                    <h2 class="fw-bold mb-4">

                        <i class="bi bi-pencil-square text-primary"></i>

                        Edit Data Tamu

                    </h2>

                    <?php if (isset($error)) : ?>

                        <div class="alert alert-danger">

                            <?= $error; ?>

                        </div>

                    <?php endif; ?>

                    <form method="POST">

                        <div class="mb-3">

                            <label class="form-label">
                                Nama Tamu
                            </label>

                            <input
                                type="text"
                                name="nama_tamu"
                                class="form-control"
                                value="<?= htmlspecialchars($tamu['nama_tamu']); ?>"
                                required>

                        </div>

                        <div class="mb-3">

                            <label class="form-label">
                                Instansi
                            </label>

                            <input
                                type="text"
                                name="instansi"
                                class="form-control"
                                value="<?= htmlspecialchars($tamu['instansi']); ?>"
                                required>

                        </div>

                        <div class="mb-3">

                            <label class="form-label">
                                Tujuan
                            </label>

                            <input
                                type="text"
                                name="tujuan"
                                class="form-control"
                                value="<?= htmlspecialchars($tamu['tujuan']); ?>"
                                required>

                        </div>

                        <div class="mb-3">

                            <label class="form-label">
                                Waktu Kunjungan
                            </label>

                            <input
                                type="datetime-local"
                                name="waktu_kunjungan"
                                class="form-control"
                                value="<?= date('Y-m-d\TH:i', strtotime($tamu['waktu_kunjungan'])); ?>"
                                required>

                        </div>

                        <div class="mb-4">

                            <label class="form-label">
                                Keterangan
                            </label>

                            <textarea
                                name="keterangan"
                                rows="4"
                                class="form-control"><?= htmlspecialchars($tamu['keterangan']); ?></textarea>

                        </div>

                        <div class="d-flex justify-content-between">

                            <a href="data_tamu.php" class="btn btn-secondary">

                                <i class="bi bi-arrow-left"></i>

                                Kembali

                            </a>

                            <button
                                type="submit"
                                name="update"
                                class="btn btn-primary">

                                <i class="bi bi-check-circle"></i>

                                Simpan Perubahan

                            </button>

                        </div>

                    </form>

                </div>

            </div>

        </div>

    </div>

</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="../assets/js/script.js"></script>

</body>

</html>