<?php

include "../includes/session.php";
include "../includes/koneksi.php";

$query = mysqli_query($koneksi, "SELECT COUNT(*) AS total_tamu FROM tamu");
$data = mysqli_fetch_assoc($query);

$total_tamu = $data['total_tamu'];

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard | Buku Tamu Digital</title>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- CSS -->
    <link rel="stylesheet" href="../assets/css/style.css">

</head>

<body>

<div class="overlay"></div>

<?php include "../includes/navbar.php"; ?>

<div class="container py-5">

    <div class="row">

        <div class="col-lg-12">

            <div class="card shadow-sm border-0 mb-4">

                <div class="card-body p-4">

                    <h2 class="fw-bold">

                        Selamat Datang,
                        <?= $_SESSION['nama_lengkap']; ?>

                    </h2>

                    <p class="text-secondary mb-0">

                        Selamat datang di Dashboard Buku Tamu Digital.
                        Gunakan menu yang tersedia untuk mengelola data tamu.

                    </p>

                </div>

            </div>

        </div>

    </div>

    <div class="row g-4">

        <div class="col-md-6">

            <div class="card shadow-sm border-0 h-100">

                <div class="card-body text-center p-4">

                    <i class="bi bi-people-fill display-4 text-primary"></i>

                    <h5 class="mt-3">

                        Total Tamu

                    </h5>

                    <h2 class="fw-bold text-primary">

                        <?= $total_tamu; ?>

                    </h2>

                </div>

            </div>

        </div>

        <div class="col-md-6">

            <div class="card shadow-sm border-0 h-100">

                <div class="card-body text-center p-4">

                    <i class="bi bi-table display-4 text-primary"></i>

                    <h5 class="mt-3">

                        Kelola Data Tamu

                    </h5>

                    <p class="text-secondary">

                        Lihat, tambah, ubah, atau hapus data tamu.

                    </p>

                    <a href="data_tamu.php" class="btn btn-primary">

                        <i class="bi bi-arrow-right-circle"></i>

                        Buka Data Tamu

                    </a>

                </div>

            </div>

        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="../assets/js/script.js"></script>

</body>

</html>